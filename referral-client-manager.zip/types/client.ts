export interface Client {
  id: string;
  name: string;
  phoneNumber: string;
  isOrange: boolean;
  isGreen: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ClientInput {
  name: string;
  phoneNumber: string;
}