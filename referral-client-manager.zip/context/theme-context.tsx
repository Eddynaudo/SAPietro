import { createContext, useContext, ReactNode } from "react";

interface ThemeColors {
  background: string;
  cardBackground: string;
  text: string;
  textSecondary: string;
  primary: string;
  primaryDark: string;
  border: string;
  error: string;
  errorLight: string;
}

interface ThemeContextType {
  colors: ThemeColors;
}

const darkThemeColors: ThemeColors = {
  background: "#121212",
  cardBackground: "#1E1E1E",
  text: "#FFFFFF",
  textSecondary: "#A0A0A0",
  primary: "#4ADE80",
  primaryDark: "#22C55E",
  border: "#2A2A2A",
  error: "#EF4444",
  errorLight: "rgba(239, 68, 68, 0.1)",
};

const ThemeContext = createContext<ThemeContextType>({
  colors: darkThemeColors,
});

export function ThemeProvider({ children }: { children: ReactNode }) {
  return (
    <ThemeContext.Provider value={{ colors: darkThemeColors }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}