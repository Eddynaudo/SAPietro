import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";

interface User {
  id: string;
  name: string;
  phoneNumber: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  signIn: (phoneNumber: string, password: string) => Promise<void>;
  signUp: (name: string, phoneNumber: string, password: string) => Promise<void>;
  verifyCode: (code: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  signIn: async () => {},
  signUp: async () => {},
  verifyCode: async () => {},
  signOut: async () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [pendingUser, setPendingUser] = useState<any>(null);

  useEffect(() => {
    // Load user from storage on app start
    const loadUser = async () => {
      try {
        const userJson = await AsyncStorage.getItem("user");
        if (userJson) {
          setUser(JSON.parse(userJson));
        }
      } catch (error) {
        console.error("Failed to load user:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadUser();
  }, []);

  const signIn = async (phoneNumber: string, password: string) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if user exists in storage
      const usersJson = await AsyncStorage.getItem("users");
      const users = usersJson ? JSON.parse(usersJson) : [];
      
      const foundUser = users.find(
        (u: any) => u.phoneNumber === phoneNumber && u.password === password
      );
      
      if (!foundUser) {
        throw new Error("Invalid credentials");
      }
      
      // Create user object without password
      const userToStore = {
        id: foundUser.id,
        name: foundUser.name,
        phoneNumber: foundUser.phoneNumber,
      };
      
      // Store user in state and AsyncStorage
      setUser(userToStore);
      await AsyncStorage.setItem("user", JSON.stringify(userToStore));
      
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      throw error;
    }
  };

  const signUp = async (name: string, phoneNumber: string, password: string) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if user already exists
      const usersJson = await AsyncStorage.getItem("users");
      const users = usersJson ? JSON.parse(usersJson) : [];
      
      if (users.some((u: any) => u.phoneNumber === phoneNumber)) {
        throw new Error("Phone number already in use");
      }
      
      // Create new user but don't store it yet
      const newUser = {
        id: Date.now().toString(),
        name,
        phoneNumber,
        password,
      };
      
      // Store pending user for verification
      setPendingUser(newUser);
      
      // In a real app, we would send a verification code to the phone number
      // For this demo, we'll just simulate it
      
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      throw error;
    }
  };

  const verifyCode = async (code: string) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // For demo purposes, any 4-digit code will work
      // In a real app, we would validate the code against what was sent
      if (code.length !== 4 || !/^\d{4}$/.test(code)) {
        throw new Error("Invalid verification code");
      }
      
      if (!pendingUser) {
        throw new Error("No pending registration");
      }
      
      // Get existing users
      const usersJson = await AsyncStorage.getItem("users");
      const users = usersJson ? JSON.parse(usersJson) : [];
      
      // Add new user to users list
      users.push(pendingUser);
      await AsyncStorage.setItem("users", JSON.stringify(users));
      
      // Create user object without password
      const userToStore = {
        id: pendingUser.id,
        name: pendingUser.name,
        phoneNumber: pendingUser.phoneNumber,
      };
      
      // Store user in state and AsyncStorage
      setUser(userToStore);
      await AsyncStorage.setItem("user", JSON.stringify(userToStore));
      
      // Clear pending user
      setPendingUser(null);
      
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      throw error;
    }
  };

  const signOut = async () => {
    try {
      await AsyncStorage.removeItem("user");
      setUser(null);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    } catch (error) {
      console.error("Failed to sign out:", error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, signIn, signUp, verifyCode, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}