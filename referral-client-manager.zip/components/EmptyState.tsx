import { View, Text, StyleSheet } from "react-native";
import { useTheme } from "@/context/theme-context";
import { Users } from "lucide-react-native";

export function EmptyState() {
  const { colors } = useTheme();

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
      padding: 24,
    },
    iconContainer: {
      width: 80,
      height: 80,
      borderRadius: 40,
      backgroundColor: colors.cardBackground,
      justifyContent: "center",
      alignItems: "center",
      marginBottom: 24,
    },
    title: {
      fontSize: 20,
      fontWeight: "bold",
      color: colors.text,
      marginBottom: 8,
      textAlign: "center",
    },
    message: {
      fontSize: 16,
      color: colors.textSecondary,
      textAlign: "center",
      maxWidth: 280,
    },
  });

  return (
    <View style={styles.container}>
      <View style={styles.iconContainer}>
        <Users size={40} color={colors.textSecondary} />
      </View>
      <Text style={styles.title}>No clients yet</Text>
      <Text style={styles.message}>
        Add your first referral client by tapping the + button below
      </Text>
    </View>
  );
}