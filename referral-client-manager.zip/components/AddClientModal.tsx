import { useState } from "react";
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Modal, KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";

import { useTheme } from "@/context/theme-context";
import { useClientStore } from "@/store/client-store";
import { User, Phone, X } from "lucide-react-native";
import { ClientInput } from "@/types/client";

interface AddClientModalProps {
  visible: boolean;
  onClose: () => void;
}

export function AddClientModal({ visible, onClose }: AddClientModalProps) {
  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false); // Flag to prevent duplicate submissions

  const { colors } = useTheme();
  const { addClient } = useClientStore();

  const handleAdd = async () => {
    // Prevent duplicate submissions
    if (isSubmitting) return;
    
    if (!name || !phoneNumber) {
      setError("Please fill in all fields");
      return;
    }

    setError("");
    setIsLoading(true);
    setIsSubmitting(true); // Set flag to prevent duplicate submissions
    
    try {
      const clientData: ClientInput = {
        name,
        phoneNumber,
      };
      
      await addClient(clientData);
      
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      resetForm();
      onClose();
    } catch (err) {
      setError("Failed to add client");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setIsLoading(false);
      setIsSubmitting(false); // Reset flag after submission completes
    }
  };

  const resetForm = () => {
    setName("");
    setPhoneNumber("");
    setError("");
    setIsSubmitting(false);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const styles = StyleSheet.create({
    modalContainer: {
      flex: 1,
      justifyContent: "flex-end",
      backgroundColor: "rgba(0, 0, 0, 0.5)",
    },
    modalContent: {
      backgroundColor: colors.background,
      borderTopLeftRadius: 24,
      borderTopRightRadius: 24,
      paddingHorizontal: 24,
      paddingTop: 24,
      paddingBottom: Platform.OS === "ios" ? 48 : 24,
      maxHeight: "80%",
    },
    header: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 24,
    },
    title: {
      fontSize: 20,
      fontWeight: "bold",
      color: colors.text,
    },
    closeButton: {
      padding: 4,
    },
    inputContainer: {
      marginBottom: 16,
      borderRadius: 12,
      backgroundColor: colors.cardBackground,
      flexDirection: "row",
      alignItems: "center",
      paddingHorizontal: 16,
      height: 56,
    },
    input: {
      flex: 1,
      height: 56,
      color: colors.text,
      marginLeft: 12,
    },
    button: {
      height: 56,
      borderRadius: 12,
      overflow: "hidden",
      marginTop: 16,
    },
    buttonContent: {
      height: 56,
      alignItems: "center",
      justifyContent: "center",
    },
    buttonText: {
      color: "#000",
      fontSize: 16,
      fontWeight: "600",
    },
    errorText: {
      color: colors.error,
      marginBottom: 16,
      textAlign: "center",
    },
  });

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={handleClose}
    >
      <KeyboardAvoidingView 
        style={styles.modalContainer} 
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.modalContent}>
          <View style={styles.header}>
            <Text style={styles.title}>Add New Client</Text>
            <TouchableOpacity style={styles.closeButton} onPress={handleClose}>
              <X size={24} color={colors.text} />
            </TouchableOpacity>
          </View>

          <ScrollView>
            {error ? <Text style={styles.errorText}>{error}</Text> : null}

            <View style={styles.inputContainer}>
              <User size={20} color={colors.textSecondary} />
              <TextInput
                style={styles.input}
                placeholder="Full Name"
                placeholderTextColor={colors.textSecondary}
                value={name}
                onChangeText={setName}
              />
            </View>

            <View style={styles.inputContainer}>
              <Phone size={20} color={colors.textSecondary} />
              <TextInput
                style={styles.input}
                placeholder="Phone Number"
                placeholderTextColor={colors.textSecondary}
                value={phoneNumber}
                onChangeText={setPhoneNumber}
                keyboardType="phone-pad"
              />
            </View>

            <TouchableOpacity 
              style={styles.button} 
              onPress={handleAdd}
              disabled={isLoading || isSubmitting}
            >
              <LinearGradient
                colors={[colors.primary, colors.primaryDark]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.buttonContent}
              >
                {isLoading ? (
                  <ActivityIndicator color="#000" />
                ) : (
                  <Text style={styles.buttonText}>Add Client</Text>
                )}
              </LinearGradient>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}