import { View, Text, StyleSheet, TouchableOpacity, Modal } from "react-native";
import { useTheme } from "@/context/theme-context";
import { AlertTriangle } from "lucide-react-native";

interface ConfirmationModalProps {
  visible: boolean;
  title: string;
  message: string;
  confirmText: string;
  cancelText: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export function ConfirmationModal({
  visible,
  title,
  message,
  confirmText,
  cancelText,
  onConfirm,
  onCancel,
}: ConfirmationModalProps) {
  const { colors } = useTheme();

  const styles = StyleSheet.create({
    modalContainer: {
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: "rgba(0, 0, 0, 0.5)",
      padding: 24,
    },
    modalContent: {
      backgroundColor: colors.background,
      borderRadius: 16,
      padding: 24,
      width: "100%",
      maxWidth: 320,
      alignItems: "center",
    },
    iconContainer: {
      width: 56,
      height: 56,
      borderRadius: 28,
      backgroundColor: colors.errorLight,
      justifyContent: "center",
      alignItems: "center",
      marginBottom: 16,
    },
    title: {
      fontSize: 20,
      fontWeight: "bold",
      color: colors.text,
      marginBottom: 8,
      textAlign: "center",
    },
    message: {
      fontSize: 16,
      color: colors.textSecondary,
      marginBottom: 24,
      textAlign: "center",
    },
    buttonsContainer: {
      flexDirection: "row",
      width: "100%",
    },
    cancelButton: {
      flex: 1,
      height: 48,
      borderRadius: 8,
      backgroundColor: colors.cardBackground,
      justifyContent: "center",
      alignItems: "center",
      marginRight: 8,
    },
    cancelText: {
      color: colors.text,
      fontWeight: "600",
    },
    confirmButton: {
      flex: 1,
      height: 48,
      borderRadius: 8,
      backgroundColor: colors.error,
      justifyContent: "center",
      alignItems: "center",
      marginLeft: 8,
    },
    confirmText: {
      color: "#fff",
      fontWeight: "600",
    },
  });

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <View style={styles.iconContainer}>
            <AlertTriangle size={28} color={colors.error} />
          </View>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.message}>{message}</Text>
          <View style={styles.buttonsContainer}>
            <TouchableOpacity style={styles.cancelButton} onPress={onCancel}>
              <Text style={styles.cancelText}>{cancelText}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.confirmButton} onPress={onConfirm}>
              <Text style={styles.confirmText}>{confirmText}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}