import { useState } from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { useTheme } from "@/context/theme-context";
import { Edit2, Trash2 } from "lucide-react-native";
import { Client } from "@/types/client";
import { useClientStore } from "@/store/client-store";
import { ConfirmationModal } from "./ConfirmationModal";

interface ClientCardProps {
  client: Client;
  onEdit: () => void;
  onDelete: () => void;
}

export function ClientCard({ client, onEdit, onDelete }: ClientCardProps) {
  const { colors } = useTheme();
  const { updateClient } = useClientStore();
  const [isGreenConfirmVisible, setIsGreenConfirmVisible] = useState(false);

  const handleOrangeToggle = async () => {
    await updateClient(client.id, {
      ...client,
      isOrange: !client.isOrange,
      // If turning off orange, also turn off green
      isGreen: !client.isOrange ? false : client.isGreen
    });
  };

  const handleGreenToggle = async () => {
    // Can only toggle green if orange is active
    if (client.isOrange) {
      // If green is already active, show confirmation dialog before deactivating
      if (client.isGreen) {
        setIsGreenConfirmVisible(true);
      } else {
        // If green is not active, activate it directly
        await updateClient(client.id, {
          ...client,
          isGreen: true
        });
      }
    }
  };

  const handleConfirmGreenDeactivation = async () => {
    await updateClient(client.id, {
      ...client,
      isGreen: false
    });
    setIsGreenConfirmVisible(false);
  };

  const styles = StyleSheet.create({
    container: {
      backgroundColor: colors.cardBackground,
      borderRadius: 12,
      padding: 16,
      marginBottom: 12,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 3,
      elevation: 2,
    },
    header: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 12,
    },
    name: {
      fontSize: 18,
      fontWeight: "600",
      color: colors.text,
      flex: 1,
    },
    actions: {
      flexDirection: "row",
    },
    actionButton: {
      padding: 8,
      marginLeft: 8,
    },
    statusButtons: {
      flexDirection: "row",
      marginRight: 8,
    },
    statusButton: {
      width: 36,
      height: 36,
      borderRadius: 18,
      justifyContent: "center",
      alignItems: "center",
      marginLeft: 8,
      borderWidth: 1,
    },
    orangeButton: {
      backgroundColor: client.isOrange ? "#FF9800" : "transparent",
      borderColor: "#FF9800",
    },
    greenButton: {
      backgroundColor: client.isGreen ? "#4ADE80" : "transparent",
      borderColor: "#4ADE80",
      opacity: client.isOrange ? 1 : 0.5,
    },
  });

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.name}>{client.name}</Text>
        <View style={styles.statusButtons}>
          <TouchableOpacity 
            style={[styles.statusButton, styles.orangeButton]} 
            onPress={handleOrangeToggle}
          />
          <TouchableOpacity 
            style={[styles.statusButton, styles.greenButton]} 
            onPress={handleGreenToggle}
            disabled={!client.isOrange}
          />
        </View>
        <View style={styles.actions}>
          <TouchableOpacity style={styles.actionButton} onPress={onEdit}>
            <Edit2 size={18} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton} onPress={onDelete}>
            <Trash2 size={18} color={colors.error} />
          </TouchableOpacity>
        </View>
      </View>

      <ConfirmationModal
        visible={isGreenConfirmVisible}
        title="Deactivate Green Status"
        message="Are you sure you want to deactivate the green status for this client?"
        confirmText="Deactivate"
        cancelText="Cancel"
        onConfirm={handleConfirmGreenDeactivation}
        onCancel={() => setIsGreenConfirmVisible(false)}
      />
    </View>
  );
}