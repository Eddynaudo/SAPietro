import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Client, ClientInput } from "@/types/client";

interface ClientStore {
  clients: Client[];
  isLoading: boolean;
  error: string | null;
  getClients: () => Promise<void>;
  getClientById: (id: string) => Client | undefined;
  addClient: (client: ClientInput) => Promise<void>;
  updateClient: (id: string, client: Partial<Client>) => Promise<void>;
  deleteClient: (id: string) => Promise<void>;
}

export const useClientStore = create<ClientStore>()(
  persist(
    (set, get) => ({
      clients: [],
      isLoading: false,
      error: null,

      getClients: async () => {
        set({ isLoading: true, error: null });
        try {
          // In a real app, you would fetch from an API
          // For this demo, we're just returning the stored clients
          set({ isLoading: false });
        } catch (error) {
          set({ 
            isLoading: false, 
            error: "Failed to fetch clients" 
          });
        }
      },

      getClientById: (id) => {
        return get().clients.find(client => client.id === id);
      },

      addClient: async (clientInput) => {
        set({ isLoading: true, error: null });
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 500));
          
          const newClient: Client = {
            id: Date.now().toString(),
            ...clientInput,
            isOrange: false,
            isGreen: false,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          
          set(state => ({
            clients: [...state.clients, newClient],
            isLoading: false,
          }));
        } catch (error) {
          set({ 
            isLoading: false, 
            error: "Failed to add client" 
          });
          throw error;
        }
      },

      updateClient: async (id, clientUpdate) => {
        set({ isLoading: true, error: null });
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 500));
          
          set(state => ({
            clients: state.clients.map(client => 
              client.id === id 
                ? { 
                    ...client, 
                    ...clientUpdate, 
                    updatedAt: new Date().toISOString() 
                  } 
                : client
            ),
            isLoading: false,
          }));
        } catch (error) {
          set({ 
            isLoading: false, 
            error: "Failed to update client" 
          });
          throw error;
        }
      },

      deleteClient: async (id) => {
        set({ isLoading: true, error: null });
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 500));
          
          set(state => ({
            clients: state.clients.filter(client => client.id !== id),
            isLoading: false,
          }));
        } catch (error) {
          set({ 
            isLoading: false, 
            error: "Failed to delete client" 
          });
          throw error;
        }
      },
    }),
    {
      name: "client-storage",
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);