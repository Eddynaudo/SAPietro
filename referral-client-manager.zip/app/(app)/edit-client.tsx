import { useState, useEffect } from "react";
import { View, Text, StyleSheet, TextInput, TouchableOpacity, KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";

import { useTheme } from "@/context/theme-context";
import { useClientStore } from "@/store/client-store";
import { User, Phone } from "lucide-react-native";
import { ClientInput } from "@/types/client";

export default function EditClientScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { colors } = useTheme();
  const { getClientById, updateClient } = useClientStore();

  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (id) {
      const client = getClientById(id as string);
      if (client) {
        setName(client.name);
        setPhoneNumber(client.phoneNumber);
      }
    }
  }, [id, getClientById]);

  const handleSave = async () => {
    if (!name || !phoneNumber) {
      setError("Please fill in all fields");
      return;
    }

    setError("");
    setIsLoading(true);
    
    try {
      const clientData: ClientInput = {
        name,
        phoneNumber,
      };
      
      await updateClient(id as string, clientData);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch (err) {
      setError("Failed to update client");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setIsLoading(false);
    }
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    content: {
      flex: 1,
      padding: 24,
    },
    header: {
      marginBottom: 24,
    },
    title: {
      fontSize: 24,
      fontWeight: "bold",
      color: colors.text,
      marginBottom: 8,
    },
    subtitle: {
      fontSize: 16,
      color: colors.textSecondary,
    },
    inputContainer: {
      marginBottom: 16,
      borderRadius: 12,
      backgroundColor: colors.cardBackground,
      flexDirection: "row",
      alignItems: "center",
      paddingHorizontal: 16,
      height: 56,
    },
    input: {
      flex: 1,
      height: 56,
      color: colors.text,
      marginLeft: 12,
    },
    button: {
      height: 56,
      borderRadius: 12,
      overflow: "hidden",
      marginTop: 16,
    },
    buttonContent: {
      height: 56,
      alignItems: "center",
      justifyContent: "center",
    },
    buttonText: {
      color: "#000",
      fontSize: 16,
      fontWeight: "600",
    },
    errorText: {
      color: colors.error,
      marginBottom: 16,
      textAlign: "center",
    },
  });

  return (
    <KeyboardAvoidingView 
      style={styles.container} 
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>Edit Client</Text>
          <Text style={styles.subtitle}>Update client information</Text>
        </View>

        {error ? <Text style={styles.errorText}>{error}</Text> : null}

        <View style={styles.inputContainer}>
          <User size={20} color={colors.textSecondary} />
          <TextInput
            style={styles.input}
            placeholder="Full Name"
            placeholderTextColor={colors.textSecondary}
            value={name}
            onChangeText={setName}
          />
        </View>

        <View style={styles.inputContainer}>
          <Phone size={20} color={colors.textSecondary} />
          <TextInput
            style={styles.input}
            placeholder="Phone Number"
            placeholderTextColor={colors.textSecondary}
            value={phoneNumber}
            onChangeText={setPhoneNumber}
            keyboardType="phone-pad"
          />
        </View>

        <TouchableOpacity 
          style={styles.button} 
          onPress={handleSave}
          disabled={isLoading}
        >
          <LinearGradient
            colors={[colors.primary, colors.primaryDark]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.buttonContent}
          >
            {isLoading ? (
              <ActivityIndicator color="#000" />
            ) : (
              <Text style={styles.buttonText}>Save Changes</Text>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}