import { useState, useCallback } from "react";
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Alert, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import { useFocusEffect } from "@react-navigation/native";
import { Plus, LogOut, Download, Trash2, Edit2, User } from "lucide-react-native";
import * as Haptics from "expo-haptics";
import * as Sharing from "expo-sharing";
import * as FileSystem from "expo-file-system";
import { Platform } from "react-native";

import { useTheme } from "@/context/theme-context";
import { useAuth } from "@/context/auth-context";
import { useClientStore } from "@/store/client-store";
import { ClientCard } from "@/components/ClientCard";
import { AddClientModal } from "@/components/AddClientModal";
import { ConfirmationModal } from "@/components/ConfirmationModal";
import { EmptyState } from "@/components/EmptyState";
import { Client } from "@/types/client";

export default function ClientsScreen() {
  const [isAddModalVisible, setIsAddModalVisible] = useState(false);
  const [isDeleteModalVisible, setIsDeleteModalVisible] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  
  const { colors } = useTheme();
  const { signOut, user } = useAuth();
  const router = useRouter();
  const { clients, getClients, deleteClient } = useClientStore();

  useFocusEffect(
    useCallback(() => {
      getClients();
    }, [getClients])
  );

  const handleAddClient = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setIsAddModalVisible(true);
  };

  const handleEditClient = (client: Client) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push({
      pathname: "/edit-client",
      params: { id: client.id }
    });
  };

  const handleDeletePress = (client: Client) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setSelectedClient(client);
    setIsDeleteModalVisible(true);
  };

  const handleConfirmDelete = async () => {
    if (selectedClient) {
      await deleteClient(selectedClient.id);
      setIsDeleteModalVisible(false);
      setSelectedClient(null);
    }
  };

  const handleExportData = async () => {
    if (Platform.OS === "web") {
      Alert.alert("Export not available", "This feature is not available on web.");
      return;
    }

    try {
      setIsExporting(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

      // Create CSV content
      let csvContent = "Name,Phone Number,Orange Status,Green Status\n";
      clients.forEach(client => {
        csvContent += `${client.name},${client.phoneNumber},${client.isOrange ? "Yes" : "No"},${client.isGreen ? "Yes" : "No"}\n`;
      });

      // Save to file
      const fileName = `referral_clients_${new Date().toISOString().split('T')[0]}.csv`;
      const filePath = `${FileSystem.documentDirectory}${fileName}`;
      
      await FileSystem.writeAsStringAsync(filePath, csvContent);
      
      // Share the file
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(filePath);
      } else {
        Alert.alert("Sharing not available", "Sharing is not available on this device");
      }
    } catch (error) {
      console.error("Export error:", error);
      Alert.alert("Export Failed", "There was an error exporting your data.");
    } finally {
      setIsExporting(false);
    }
  };

  const handleLogout = () => {
    Alert.alert(
      "Logout",
      "Are you sure you want to logout?",
      [
        { text: "Cancel", style: "cancel" },
        { 
          text: "Logout", 
          style: "destructive",
          onPress: () => signOut()
        }
      ]
    );
  };

  const renderItem = ({ item }: { item: Client }) => (
    <ClientCard
      client={item}
      onEdit={() => handleEditClient(item)}
      onDelete={() => handleDeletePress(item)}
    />
  );

  // Calculate totals
  const totalClients = clients.length;
  const totalOrangeValue = totalClients * 80;
  const totalGreenValue = clients.filter(client => client.isGreen).length * 80;

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      paddingHorizontal: 16,
      paddingVertical: 12,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    headerTitle: {
      fontSize: 18,
      fontWeight: "bold",
      color: colors.text,
    },
    content: {
      flex: 1,
      padding: 16,
    },
    listContainer: {
      flex: 1,
    },
    fab: {
      position: "absolute",
      bottom: 24,
      right: 24,
      width: 56,
      height: 56,
      borderRadius: 28,
      backgroundColor: colors.primary,
      justifyContent: "center",
      alignItems: "center",
      elevation: 4,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
    },
    actionBar: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginBottom: 16,
      paddingHorizontal: 16,
    },
    actionButton: {
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: colors.cardBackground,
      paddingHorizontal: 16,
      paddingVertical: 8,
      borderRadius: 8,
    },
    actionButtonText: {
      color: colors.text,
      marginLeft: 8,
    },
    userInfo: {
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: colors.cardBackground,
      paddingHorizontal: 16,
      paddingVertical: 12,
      borderRadius: 8,
      marginBottom: 16,
    },
    userAvatar: {
      width: 36,
      height: 36,
      borderRadius: 18,
      backgroundColor: colors.primary,
      justifyContent: "center",
      alignItems: "center",
    },
    userDetails: {
      marginLeft: 12,
      flex: 1,
    },
    userName: {
      color: colors.text,
      fontWeight: "600",
      fontSize: 16,
    },
    userPhone: {
      color: colors.textSecondary,
      fontSize: 14,
    },
    summaryContainer: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginBottom: 16,
    },
    summaryBox: {
      flex: 1,
      padding: 12,
      borderRadius: 8,
      alignItems: "center",
      justifyContent: "center",
      marginHorizontal: 4,
    },
    orangeBox: {
      backgroundColor: "rgba(255, 152, 0, 0.2)",
      borderWidth: 1,
      borderColor: "#FF9800",
    },
    greenBox: {
      backgroundColor: "rgba(74, 222, 128, 0.2)",
      borderWidth: 1,
      borderColor: "#4ADE80",
    },
    summaryValue: {
      fontSize: 18,
      fontWeight: "bold",
      marginBottom: 4,
    },
    orangeValue: {
      color: "#FF9800",
    },
    greenValue: {
      color: "#4ADE80",
    },
    summaryLabel: {
      fontSize: 12,
      color: colors.textSecondary,
    },
  });

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <View style={styles.userInfo}>
          <View style={styles.userAvatar}>
            <User size={20} color="#000" />
          </View>
          <View style={styles.userDetails}>
            <Text style={styles.userName}>{user?.name}</Text>
            <Text style={styles.userPhone}>{user?.phoneNumber}</Text>
          </View>
          <TouchableOpacity onPress={handleLogout}>
            <LogOut size={20} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>

        <View style={styles.summaryContainer}>
          <View style={[styles.summaryBox, styles.orangeBox]}>
            <Text style={[styles.summaryValue, styles.orangeValue]}>€{totalOrangeValue}</Text>
            <Text style={styles.summaryLabel}>Total Clients</Text>
          </View>
          <View style={[styles.summaryBox, styles.greenBox]}>
            <Text style={[styles.summaryValue, styles.greenValue]}>€{totalGreenValue}</Text>
            <Text style={styles.summaryLabel}>Green Clients</Text>
          </View>
        </View>

        <View style={styles.actionBar}>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={handleExportData}
            disabled={isExporting || clients.length === 0}
          >
            {isExporting ? (
              <ActivityIndicator size="small" color={colors.primary} />
            ) : (
              <>
                <Download size={18} color={colors.primary} />
                <Text style={styles.actionButtonText}>Export</Text>
              </>
            )}
          </TouchableOpacity>
          
          <Text style={{ color: colors.textSecondary }}>
            {clients.length} {clients.length === 1 ? "client" : "clients"}
          </Text>
        </View>

        <FlatList
          data={clients}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ flexGrow: 1 }}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={<EmptyState />}
        />
      </View>

      <TouchableOpacity style={styles.fab} onPress={handleAddClient}>
        <Plus size={24} color="#000" />
      </TouchableOpacity>

      <AddClientModal
        visible={isAddModalVisible}
        onClose={() => setIsAddModalVisible(false)}
      />

      <ConfirmationModal
        visible={isDeleteModalVisible}
        title="Delete Client"
        message={selectedClient ? `Are you sure you want to delete ${selectedClient.name}?` : "Are you sure you want to delete this client?"}
        confirmText="Delete"
        cancelText="Cancel"
        onConfirm={handleConfirmDelete}
        onCancel={() => setIsDeleteModalVisible(false)}
      />
    </View>
  );
}