import { useEffect } from "react";
import { Redirect, Stack, useRouter } from "expo-router";
import { useAuth } from "@/context/auth-context";
import { View, Text, StyleSheet } from "react-native";

export default function AppLayout() {
  const { user, isLoading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isLoading && !user) {
      router.replace("/(auth)/login");
    }
  }, [user, isLoading, router]);

  if (isLoading) {
    return null;
  }

  if (!user) {
    return <Redirect href="/(auth)/login" />;
  }

  return (
    <Stack>
      <Stack.Screen 
        name="index" 
        options={{ 
          headerShown: true,
          headerTitle: () => (
            <View style={styles.headerContainer}>
              <Text style={styles.headerTitle}>Sector Alarm - Pietro</Text>
            </View>
          ),
          headerStyle: {
            backgroundColor: "#121212",
          },
        }} 
      />
      <Stack.Screen 
        name="edit-client" 
        options={{ 
          headerShown: true,
          headerTitle: () => (
            <View style={styles.headerContainer}>
              <Text style={styles.headerTitle}>Sector Alarm - Pietro</Text>
            </View>
          ),
          headerStyle: {
            backgroundColor: "#121212",
          },
          presentation: "modal",
        }} 
      />
    </Stack>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    paddingVertical: 48, // Increased padding to position the text even lower
  },
  headerTitle: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 18,
  }
});