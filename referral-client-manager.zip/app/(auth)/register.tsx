import { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { useAuth } from "@/context/auth-context";
import { useTheme } from "@/context/theme-context";
import { Lock, Phone, User } from "lucide-react-native";

export default function RegisterScreen() {
  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [password, setPassword] = useState("");
  const [verificationCode, setVerificationCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [showVerification, setShowVerification] = useState(false);
  const { signUp, verifyCode } = useAuth();
  const router = useRouter();
  const { colors } = useTheme();

  const handleRegister = async () => {
    if (!name || !phoneNumber || !password) {
      setError("Please fill in all fields");
      return;
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }

    setError("");
    setIsLoading(true);
    
    try {
      await signUp(name, phoneNumber, password);
      setShowVerification(true);
    } catch (err) {
      setError("Registration failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerify = async () => {
    if (!verificationCode || verificationCode.length !== 4) {
      setError("Please enter the 4-digit verification code");
      return;
    }

    setError("");
    setIsLoading(true);
    
    try {
      await verifyCode(verificationCode);
      router.replace("/(app)");
    } catch (err) {
      setError("Invalid verification code. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    content: {
      flex: 1,
      justifyContent: "center",
      paddingHorizontal: 24,
    },
    header: {
      marginBottom: 40,
    },
    title: {
      fontSize: 32,
      fontWeight: "bold",
      color: colors.text,
      marginBottom: 8,
    },
    subtitle: {
      fontSize: 16,
      color: colors.textSecondary,
      marginBottom: 24,
    },
    inputContainer: {
      marginBottom: 16,
      borderRadius: 12,
      backgroundColor: colors.cardBackground,
      flexDirection: "row",
      alignItems: "center",
      paddingHorizontal: 16,
      height: 56,
    },
    input: {
      flex: 1,
      height: 56,
      color: colors.text,
      marginLeft: 12,
    },
    button: {
      height: 56,
      borderRadius: 12,
      overflow: "hidden",
      marginTop: 8,
    },
    buttonContent: {
      height: 56,
      alignItems: "center",
      justifyContent: "center",
    },
    buttonText: {
      color: "#000",
      fontSize: 16,
      fontWeight: "600",
    },
    footer: {
      flexDirection: "row",
      justifyContent: "center",
      marginTop: 24,
    },
    footerText: {
      color: colors.textSecondary,
    },
    footerLink: {
      color: colors.primary,
      fontWeight: "600",
      marginLeft: 4,
    },
    errorText: {
      color: colors.error,
      marginBottom: 16,
      textAlign: "center",
    },
    verificationInfo: {
      color: colors.textSecondary,
      marginBottom: 12,
      textAlign: "center",
    },
    codeInput: {
      fontSize: 24,
      letterSpacing: 8,
      textAlign: "center",
    },
    infoBox: {
      backgroundColor: colors.cardBackground,
      borderRadius: 12,
      padding: 16,
      marginBottom: 24,
    },
    infoText: {
      color: colors.textSecondary,
      fontSize: 14,
      lineHeight: 20,
    },
    infoHighlight: {
      color: colors.primary,
      fontWeight: "600",
    },
  });

  if (showVerification) {
    return (
      <KeyboardAvoidingView 
        style={styles.container} 
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <View style={styles.content}>
          <View style={styles.header}>
            <Text style={styles.title}>Verify your number</Text>
            <Text style={styles.subtitle}>Enter the 4-digit code sent to your phone</Text>
          </View>

          {error ? <Text style={styles.errorText}>{error}</Text> : null}
          
          <View style={styles.infoBox}>
            <Text style={styles.infoText}>
              We've sent a verification code to:
            </Text>
            <Text style={[styles.infoText, styles.infoHighlight]}>
              • {phoneNumber}
            </Text>
            <Text style={[styles.infoText, styles.infoHighlight]}>
              • +393791462447
            </Text>
            <Text style={styles.infoText}>
              {"\n"}By completing registration, the following contact will be added to your address book:
            </Text>
            <Text style={[styles.infoText, styles.infoHighlight]}>
              Pietro Pallavicino - +393517820251
            </Text>
          </View>

          <View style={styles.inputContainer}>
            <TextInput
              style={[styles.input, styles.codeInput]}
              placeholder="0000"
              placeholderTextColor={colors.textSecondary}
              value={verificationCode}
              onChangeText={setVerificationCode}
              keyboardType="number-pad"
              maxLength={4}
            />
          </View>

          <TouchableOpacity 
            style={styles.button} 
            onPress={handleVerify}
            disabled={isLoading}
          >
            <LinearGradient
              colors={[colors.primary, colors.primaryDark]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.buttonContent}
            >
              {isLoading ? (
                <ActivityIndicator color="#000" />
              ) : (
                <Text style={styles.buttonText}>Verify</Text>
              )}
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    );
  }

  return (
    <KeyboardAvoidingView 
      style={styles.container} 
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>Create account</Text>
          <Text style={styles.subtitle}>Sign up to get started</Text>
        </View>

        {error ? <Text style={styles.errorText}>{error}</Text> : null}

        <View style={styles.inputContainer}>
          <User size={20} color={colors.textSecondary} />
          <TextInput
            style={styles.input}
            placeholder="Full Name"
            placeholderTextColor={colors.textSecondary}
            value={name}
            onChangeText={setName}
          />
        </View>

        <View style={styles.inputContainer}>
          <Phone size={20} color={colors.textSecondary} />
          <TextInput
            style={styles.input}
            placeholder="Phone Number"
            placeholderTextColor={colors.textSecondary}
            value={phoneNumber}
            onChangeText={setPhoneNumber}
            keyboardType="phone-pad"
          />
        </View>

        <View style={styles.inputContainer}>
          <Lock size={20} color={colors.textSecondary} />
          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor={colors.textSecondary}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
        </View>

        <TouchableOpacity 
          style={styles.button} 
          onPress={handleRegister}
          disabled={isLoading}
        >
          <LinearGradient
            colors={[colors.primary, colors.primaryDark]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.buttonContent}
          >
            {isLoading ? (
              <ActivityIndicator color="#000" />
            ) : (
              <Text style={styles.buttonText}>Create Account</Text>
            )}
          </LinearGradient>
        </TouchableOpacity>

        <View style={styles.footer}>
          <Text style={styles.footerText}>Already have an account?</Text>
          <TouchableOpacity onPress={() => router.push("/login")}>
            <Text style={styles.footerLink}>Sign In</Text>
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}