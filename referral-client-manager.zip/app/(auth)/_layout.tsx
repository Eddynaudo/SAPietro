import { Stack } from "expo-router";
import { View, Text, StyleSheet } from "react-native";

export default function AuthLayout() {
  return (
    <Stack screenOptions={{ 
      headerShown: true,
      headerTitle: () => (
        <View style={styles.headerContainer}>
          <Text style={styles.headerTitle}>Sector Alarm - Pietro</Text>
        </View>
      ),
      headerStyle: {
        backgroundColor: "#121212",
      },
    }}>
      <Stack.Screen name="login" />
      <Stack.Screen name="register" />
    </Stack>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    paddingVertical: 48, // Increased padding to position the text even lower
  },
  headerTitle: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 18,
  }
});